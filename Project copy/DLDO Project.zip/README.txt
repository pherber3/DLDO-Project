First install the needed requirements with:

pip install requirements.txt

in the terminal (I did this all on Mac and Steven was having issues with Anaconda on PC, 
so it might take some extra work to get it running on Windows but as long as you have the
needed packages it should be fine). Then just run through the Jupyter Notebook!

